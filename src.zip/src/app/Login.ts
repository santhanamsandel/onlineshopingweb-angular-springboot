export class Login{
    constructor(
     
      public mobileNo:string,
      public password:string
      
    ) {}
  }