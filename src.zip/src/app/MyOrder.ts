

    export class MyOrder{
        constructor(
            localdtetime:Date,
            orderstatus:String) {}
      }
    

